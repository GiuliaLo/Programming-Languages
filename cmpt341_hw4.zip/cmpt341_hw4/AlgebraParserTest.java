import java.io.*;


public class AlgebraParserTest {

    public static void main(String[] args) throws Exception {
        var reader = new FileReader("input.txt");
        var scanner = new AlgebraScanner(reader);
        var parser = new AlgebraParser(scanner);

        try {
            var value = parser.parse();
            System.out.println("Valid: " + value.value);
        } catch (Exception ex) {
            System.out.println("Invalid");
        }
    }
}
